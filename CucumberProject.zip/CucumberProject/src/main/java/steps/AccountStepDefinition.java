package steps;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AccountStepDefinition {
	public ChromeDriver driver;
	
	
	
	
	
	@Given("Launch the Browser")
	public void launch_the_browser() {
		driver=new ChromeDriver();
	}

	@Given("Load the url")
	public void load_the_url() {
		driver.get("https://login.salesforce.com/"); 
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.manage().window().maximize();
	}

	@Given("Enter the username")
	public void enter_the_username() {
		driver.findElement(By.id("username")).sendKeys("bhuvanesh.moorthy@testleaf.com");
	}

	@Given("Enter the password")
	public void enter_the_password() {
		driver.findElement(By.id("password")).sendKeys("Testleaf@2025");
	}

	@Given("Click on the Login button")
	public void click_on_the_login_button() {
		driver.findElement(By.id("Login")).click();
	}

	@Given("Click on toggle menu button from the left corner")
	public void click_on_toggle_menu_button_from_the_left_corner() {
		driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
		
	}

	@Given("Click view All and click Sales from App Launcher")
	public void click_view_all_and_click_sales_from_app_launcher() {
		driver.findElement(By.xpath("//input[@class='slds-input']")).sendKeys("Sales");
		driver.findElement(By.xpath("(//b[text()='Sales'])[3]")).click(); 
	}

	@Given("Click on Accounts tab")
	public void click_on_accounts_tab() {
		WebElement accElement = driver.findElement(By.xpath("//span[text()='Accounts']"));
		driver.executeScript("arguments[0].click()", accElement);
		
		
	}

	@Given("Click on New button")
	public void click_on_new_button() {
		driver.findElement(By.xpath("//div[text()='New']")).click();
		
	}

	@Given("Enter {string} as account name")
	public void enter_as_account_name(String string) {
		driver.findElement(By.xpath("//input[@name='Name']")).sendKeys("Mahalakshmi");
		
		
	}

	@Given("Select Ownership as Public")
	public void select_ownership_as_public() {
		WebElement ownershipElement = driver.findElement(By.xpath("//button[@aria-label='Ownership']"));
		driver.executeScript("arguments[0].click()", ownershipElement);
		driver.findElement(By.xpath("//span[text()='Public']")).click();
		
	}

	@When("Click save")
	public void click_save() {
		driver.findElement(By.xpath("//button[@name='SaveEdit']")).click();
		
	}

	@Then("verify Account name")
	public void verify_account_name() {
		String accountName = driver.findElement(By.xpath("//lightning-formatted-text[@slot='primaryField']")).getText();
		if(accountName.equals("Mahalakshmi")) {
			System.out.println("Account name :"+accountName);
		}
		else {
			System.out.println("Account name is not entered correctly");
		}
	}


}
